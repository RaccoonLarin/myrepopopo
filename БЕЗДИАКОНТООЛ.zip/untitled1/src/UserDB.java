import com.google.gson.JsonObject;
import com.google.gson.internal.bind.ArrayTypeAdapter;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Created by Salima on 03.01.2018.
 */
public class UserDB {
    private String email;
    private String pass;
    private String token;


    private String  blood_sugar, breadunits, insulin, weight, comment, date, iddiary;
    private String  xemin, xemax, xetarget, xeuser;
    private String reminderid, reminderdate, remindertext, repearday, repeatweek, norepeat;
    private String  nameProductUser, gramsProductUser, carbsProductUser;
    private String iddiaryproduct;
   // private  ArrayList<String> name_product,grams_product,carbs_product;
    private int id;
    private Connection c = null;
    private Statement stmt = null;

    public UserDB(){

        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                .getConnection(DataBaseData.getLink(),
                        DataBaseData.getName(), DataBaseData.getPass());
        c.setAutoCommit(false);
            stmt = c.createStatement();

        System.out.println("Opened database successfully");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void tokenDBPost(){
        try {
            //stmt = c.createStatement();

            String sql = "INSERT INTO token (user_id,token) "
                    + "VALUES ("+ id + ", " +"\'" + token + "\'"+ " );";
           // stmt = c.createStatement();
            stmt.executeUpdate(sql);
            c.commit();
           // ResultSet rs = stmt.executeQuery(
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void tokenDBDelete(){
        try {
            //stmt = c.createStatement();

            String sql = "DELETE FROM token WHERE token=" + "\'" + token+"\'";
            // stmt = c.createStatement();
            stmt.executeUpdate(sql);
            c.commit();
            // ResultSet rs = stmt.executeQuery(
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public String insertData(){
        try {

            String sql = "INSERT INTO diary_data (email,blood_sugar,breadunits,insulin,weight,comment,date,iddiary) "
                    + "VALUES (\'"+getEmail() +"\', " + "\'" + getBlood_sugar() +"\', " +   "\'" + getBreadunits() +"\', " +
                    "\'" + getInsulin() +"\', " +  "\'" + getWeight() +"\', " +  "\'" + getComment() +"\', " +
                    "\'" + date  + "\', "+ "\'" + getIddiary()  + "' );";
            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }

    public String updateData(){
        try {

            String sql = "UPDATE diary_data SET blood_sugar="+ "\'"+getBlood_sugar()+"\', " +
                    "breadunits="+ "\'"+getBreadunits() +"\', "+
                    "insulin="+"\'" + getInsulin() +"\', " +
                    "weight="+"\'" + getWeight() +"\', "+
                    "comment="+"\'" +getComment() +"\', "+
                    "date="+"\'" + date +"\' " +
                    "WHERE email=" + "\'"+getEmail()+"\'" + " AND date="+ "\'"+date+"\'";
            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }

    public String deleteData(){
        try {

            String sql = "DELETE FROM diary_data"+ " WHERE email=" + "\'"+getEmail()+"\'" + " AND date="+ "\'"+date+"\'";
            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }

    public String isUserExistDB(){

        try {


            System.out.print(getEmail());

            ResultSet rs = stmt.executeQuery( "SELECT * FROM user1 WHERE email=" + "\'" + getEmail() + "\'" + " AND password=\'" + getPass() + "\'");

            while ( rs.next() ) {
                String m = rs.getString("email");
                String p = rs.getString("password");
                id = rs.getInt("id");
                Token tokenObj=new Token();
                token=tokenObj.nextString();
                tokenDBPost();


                setEmail(m);
                setPass(p);

                rs.close();
                stmt.close();
                c.close();

                return token;


            }
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return "false";
          //  System.exit(0);
        }

        return "false";

    }

    public String signUpUser(){
        try {
            if(isEmailExist()) {
                return "false";
            }
            String sql = "INSERT INTO user1 (email,password) "
                    + "VALUES (\'"+getEmail() +"\', " + "\'" + getPass() +"\' );";
            String sql2 = "INSERT INTO settings_data (email,xe_user) "
                    + "VALUES (\'"+getEmail() +"\', " + "\'" + "12.0" +"\' );";
            stmt.executeUpdate(sql);
            stmt.executeUpdate(sql2);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }

    public boolean isEmailExist(){
        try {
            ResultSet rs = stmt.executeQuery( "SELECT * FROM user1 WHERE email=" + "\'" + getEmail() + "\'");
            while ( rs.next() ) {
                return true;

            }

            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();

        }

        return false;
    }



    public String getListDB(){
        try {
            ResultSet rs = stmt.executeQuery( "SELECT * FROM diary_data WHERE email=" + "\'" + getEmail() + "\'" + "ORDER BY date DESC");
            String sugar="\"sugar\":[ ";
            String breadunits="\"breadunits\":[ ";
            String insulin="\"insulin\":[ ";
            String weight="\"weight\":[ ";
            String comment="\"comment\":[ ";
            String date="\"date\":[ ";
            String iddiary="\"iddiary\":[ ";

            String xemin="\"xemin\": ";
            String xemax="\"xemax\": ";
            String xetarget="\"xetarget\": ";
            String xeuser="\"xeuser\": ";

            String reminder_id="\"reminder_id\":[ ";
            String reminder_date="\"reminder_date\":[ ";
            String reminder_text="\"reminder_text\":[ ";
            String repeat_day="\"repeat_day\":[ ";
            String repeat_week="\"repeat_week\":[ ";
            String no_repeat="\"no_repeat\":[ ";

            String diary_id="\"diary_id\":[ ";
            String name_product="\"name_product\":[ ";
            String grams_product="\"grams_product\":[ ";
            String carbs_product="\"carbs_product\":[ ";

            String grams_product_user="\"grams_product_user\":[ ";
            String carbs_product_user="\"carbs_product_user\":[ ";
            String name_product_user="\"name_product_user\":[ ";


            String tempSugar, tempBreadunit, tempInsulin, tempWeight, tempComment, tempDate;

            boolean flagDiary=false, flagnotification=false, flagProduct=false, flagProductUser=false;
            while ( rs.next() ) {
                sugar+="\""+rs.getString(3)+"\", ";
                breadunits+="\""+rs.getString(4)+"\", ";
                insulin+="\""+rs.getString(5)+"\", ";
                weight+="\""+rs.getString(6)+"\", ";
                comment+="\""+rs.getString(7)+"\", ";
                date+="\""+rs.getString(8)+"\", ";
                iddiary+="\""+rs.getString(9)+"\", ";
                flagDiary=true;
            }


            ResultSet rsNotification= stmt.executeQuery( "SELECT * FROM reminder_data WHERE email=" + "\'" + getEmail() + "\'");

            while ( rsNotification.next() ) {

                reminder_id+="\""+rsNotification.getString(3)+"\", ";
                reminder_date+="\""+rsNotification.getString(4)+"\", ";
                reminder_text+="\""+rsNotification.getString(5)+"\", ";
                repeat_day+="\""+rsNotification.getString(6)+"\", ";
                repeat_week+="\""+rsNotification.getString(7)+"\", ";
                no_repeat+="\""+rsNotification.getString(8)+"\", ";
                flagnotification=true;


            }


            ResultSet rsFoodData= stmt.executeQuery( "SELECT * FROM food_data WHERE email=" + "\'" + getEmail() + "\'");

            while ( rsFoodData.next() ) {

                diary_id+="\""+rsFoodData.getString(3)+"\", ";
                name_product+="\""+rsFoodData.getString(4)+"\", ";
                grams_product+="\""+rsFoodData.getString(5)+"\", ";
                carbs_product+="\""+rsFoodData.getString(6)+"\", ";
                flagProduct=true;


            }

            ResultSet rsUserProduct= stmt.executeQuery( "SELECT * FROM food_data_user WHERE email=" + "\'" + getEmail() + "\'");

            while ( rsUserProduct.next() ) {
                grams_product_user+="\""+rsUserProduct.getString(2)+"\", ";
                carbs_product_user+="\""+rsUserProduct.getString(3)+"\", ";
                name_product_user+="\""+rsUserProduct.getString(4)+"\", ";
                flagProductUser=true;

            }



            ResultSet rsSettings = stmt.executeQuery( "SELECT * FROM settings_data WHERE email=" + "\'" + getEmail() + "\'");
            boolean flag=false;
            while ( rsSettings.next() ) {
                xemin+="\""+rsSettings.getString(3)+"\", \n";

                xemax+="\""+rsSettings.getString(4)+"\", \n";

                xetarget+="\""+rsSettings.getString(5)+"\", \n";

                xeuser+="\""+rsSettings.getString(6)+"\", \n";

                flag=true;

            }

            if(!flag){


                xemin+="\""+"\", \n";

                xemax+="\""+"\", \n";

                xetarget+="\""+"\", \n";

                xeuser+="\""+"12"+"\", \n";
            }


            if(flagDiary) {
                sugar = sugar.substring(0, sugar.length() - 2) + " ], \n";
                breadunits = breadunits.substring(0, breadunits.length() - 2) + " ], \n";
                insulin = insulin.substring(0, insulin.length() - 2) + " ], \n";
                weight = weight.substring(0, weight.length() - 2) + " ], \n";
                comment = comment.substring(0, comment.length() - 2) + " ],\n";
                date = date.substring(0, date.length() - 2) + " ],\n";
                iddiary = iddiary.substring(0, iddiary.length() - 2) + " ]\n";
            } else {
                sugar += "], \n";
                breadunits +=  "], \n";
                insulin +=  "], \n";
                weight +=  "], \n";
                comment +=  "],\n";
                date +=  "],\n";
                iddiary +=  "]\n";
            }

            if(flagnotification) {
                reminder_id = reminder_id.substring(0, reminder_id.length() - 2) + " ], \n";
                reminder_date = reminder_date.substring(0, reminder_date.length() - 2) + " ], \n";
                reminder_text = reminder_text.substring(0, reminder_text.length() - 2) + " ], \n";
                repeat_day = repeat_day.substring(0, repeat_day.length() - 2) + " ], \n";
                repeat_week = repeat_week.substring(0, repeat_week.length() - 2) + " ], \n";
                no_repeat = no_repeat.substring(0, no_repeat.length() - 2) + " ], \n";
            } else {
                reminder_id +=  "], \n";
                reminder_date +=  "], \n";
                reminder_text +=  "], \n";
                repeat_day +=  "], \n";
                repeat_week += "], \n";
                no_repeat += "], \n";
            }


            if(flagProduct) {
                diary_id = diary_id.substring(0, diary_id.length() - 2) + " ], \n";
                name_product = name_product.substring(0, name_product.length() - 2) + " ], \n";
                grams_product = grams_product.substring(0, grams_product.length() - 2) + " ], \n";
                carbs_product = carbs_product.substring(0, carbs_product.length() - 2) + " ], \n";
            } else {
                diary_id +=  "], \n";
                name_product +=  "], \n";
                grams_product +=  "], \n";
                carbs_product +=  "], \n";

            }

            if(flagProductUser) {
                grams_product_user = grams_product_user.substring(0, grams_product_user.length() - 2) + " ], \n";
                carbs_product_user = carbs_product_user.substring(0, carbs_product_user.length() - 2) + " ], \n";
                name_product_user = name_product_user.substring(0, name_product_user.length() - 2) + " ], \n";
            } else {
                grams_product_user += "], \n";
                carbs_product_user +=  "], \n";
                name_product_user +=  "], \n";
            }




            String jsonBody="{\n" + xemin+xemax+xetarget+xeuser+
                    reminder_id+reminder_date+reminder_text+ repeat_day+repeat_week+no_repeat+
                    grams_product_user +  carbs_product_user +name_product_user +
                    diary_id+name_product+grams_product+carbs_product+ sugar + breadunits+insulin+weight+comment+date+iddiary+
                    "}";



            rs.close();
            rsSettings.close();
            System.out.print(jsonBody);
            return  jsonBody;
        } catch (SQLException e) {
            e.printStackTrace();

        }

        return "";
    }

    public String insertSettings(){
        try {

            ResultSet rs = stmt.executeQuery( "SELECT * FROM settings_data WHERE email=" + "\'" + getEmail() + "\'");
            while ( rs.next() ) {
                updateSettings();
                return "";
            }

            String sql = "INSERT INTO settings_data (email,xe_min,xe_max,xe_target,xe_user) "
                    + "VALUES (\'"+getEmail() +"\', " + "\'" + getXemin() +"\', " +   "\'" + getXemax() +"\', " +
                    "\'" + getXetarget() +"\', " +
                    "\'" + getXeuser()  + "\' );";
            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }
    public String updateSettings(){
        try {
            String sql = "UPDATE settings_data SET xe_min="+ "\'"+getXemin()+"\', " +
                    "xe_max="+ "\'"+getXemax()+"\', "+
                    "xe_target="+"\'" + getXetarget() +"\', " +
                    "xe_user="+"\'" + getXeuser() +"\' " +
                    "WHERE email=" + "\'"+getEmail()+"\'";
            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }


    public String insertReminder(){
        try {


            String sql = "INSERT INTO reminder_data (email,reminder_id,reminder_date,reminder_text,repeat_day,repeat_week,no_repeat) "
                    + "VALUES (\'"+getEmail() +"\', " + "\'" + getReminderid() +"\', " +   "\'" + getReminderdate() +"\', " +
                    "\'" + getRemindertext() +"\', " +
                    "\'" + getRepearday() +"\', " +
                    "\'" + getRepeatweek() +"\', " +
                    "\'" + getNorepeat()  + "\' );";
            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }


    public String updateReminder(){


            deleteReminder();
            insertReminder();

            return insertReminder();
    }

    public String deleteReminder(){
        try {
            String sql = "DELETE FROM reminder_data"+ " WHERE email=" + "\'"+getEmail()+"\'" + " AND reminder_id="+ "\'"+getReminderid()+"\'";

            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }


    public String insertProduct(ArrayList<String> name, ArrayList<String> grams,ArrayList<String> carbs){
        try {
            String sql2 = "DELETE FROM food_data"+ " WHERE email=" + "\'"+getEmail()+"\'" + " AND diary_id="+ getIddiaryproduct();

            System.out.println(sql2);

            stmt.executeUpdate(sql2);
            c.commit();

            String sql="";
            for(int i=0; i<name.size(); i++) {
                    sql = "INSERT INTO food_data (email,diary_id,name_product,grams_product,carbs_product) "
                        + "VALUES (\'" + getEmail() + "\', " + "\'" + getIddiaryproduct() + "\', " + "\'" + name.get(i) + "\', " +
                        "\'" + grams.get(i) + "\', " +
                        "\'" + carbs.get(i) + "\' );";
                stmt.executeUpdate(sql);
                // System.out.println(sql);
            }

            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }


    public String deleteProduct(){
        try {
            String sql = "DELETE FROM food_data"+ " WHERE email=" + "\'"+getEmail()+"\'" + " AND diary_id="+ getIddiaryproduct();

            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }


    public String insertProductUser(){
        try {



            String sql = "INSERT INTO food_data_user (grams_product,carbs_product,name_product,email) "
                    + "VALUES (\'"+getGramsProductUser() +"\', " + "\'" + getCarbsProductUser() +"\', " +   "\'" + getNameProductUser()+"\', " +
                    "\'" + getEmail()  + "\' );";
            System.out.println(sql);

            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
            return "true";

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return  "false";
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    public void setToken(String token) {
        this.token = token;
    }
    public void setBlood_sugar(String blood_sugar) {
        this.blood_sugar = blood_sugar;
    }

    public void setBreadunits(String breadunits) {
        this.breadunits = breadunits;
    }

    public void setInsulin(String insulin) {
        this.insulin = insulin;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public String getBlood_sugar() {
        return blood_sugar;
    }

    public String getBreadunits() {
        return breadunits;
    }

    public String getInsulin() {
        return insulin;
    }

    public String getWeight() {
        return weight;
    }

    public String getComment() {
        return comment;
    }

    public String getIddiary() {
        return iddiary;
    }

    public void setIddiary(String iddiary) {
        this.iddiary = iddiary;
    }

    public String getXemin() {
        return xemin;
    }

    public void setXemin(String xemin) {
        this.xemin = xemin;
    }

    public String getXemax() {
        return xemax;
    }

    public void setXemax(String xemax) {
        this.xemax = xemax;
    }

    public String getXetarget() {
        return xetarget;
    }

    public void setXetarget(String xetarget) {
        this.xetarget = xetarget;
    }

    public String getXeuser() {
        return xeuser;
    }

    public void setXeuser(String xeuser) {
        this.xeuser = xeuser;
    }

    public String getReminderid() {
        return reminderid;
    }

    public void setReminderid(String reminderid) {
        this.reminderid = reminderid;
    }

    public String getReminderdate() {
        return reminderdate;
    }

    public void setReminderdate(String reminderdate) {
        this.reminderdate = reminderdate;
    }

    public String getIddiaryproduct() {
        return iddiaryproduct;
    }

    public void setIddiaryproduct(String iddiaryproduct) {
        this.iddiaryproduct = iddiaryproduct;
    }

    public String getRemindertext() {
        return remindertext;
    }

    public void setRemindertext(String remindertext) {
        this.remindertext = remindertext;
    }

    public String getRepearday() {
        return repearday;
    }

    public void setRepearday(String repearday) {
        this.repearday = repearday;
    }

    public String getRepeatweek() {
        return repeatweek;
    }

    public void setRepeatweek(String repeatweek) {
        this.repeatweek = repeatweek;
    }

    public String getNorepeat() {
        return norepeat;
    }

    public void setNorepeat(String norepeat) {
        this.norepeat = norepeat;
    }

    public String getNameProductUser() {
        return nameProductUser;
    }

    public void setNameProductUser(String nameProductUser) {
        this.nameProductUser = nameProductUser;
    }

    public String getGramsProductUser() {
        return gramsProductUser;
    }

    public void setGramsProductUser(String gramsProductUser) {
        this.gramsProductUser = gramsProductUser;
    }

    public String getCarbsProductUser() {
        return carbsProductUser;
    }

    public void setCarbsProductUser(String carbsProductUser) {
        this.carbsProductUser = carbsProductUser;
    }
}
