/**
 * Created by Salima on 23.12.2017.
 */
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class httpservak {

  public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
      server.createContext("/", new MyHandler());
        server.setExecutor(null); // creates a default executor
        server.start();
    }

    static class MyHandler implements HttpHandler {
        String bd;


       public String connectDB(){
           bd="{\"diary\": {\n";

           Connection c = null;
           Statement stmt = null;
           try {
               Class.forName("org.postgresql.Driver");
               c = DriverManager
                       .getConnection("jdbc:postgresql://localhost:5432/postgres",
                               "postgres", "ed371612");
               c.setAutoCommit(false);
               System.out.println("Opened database successfully");

               stmt = c.createStatement();
               ResultSet rs = stmt.executeQuery( "SELECT * FROM data;" );
               while ( rs.next() ) {
                   bd+="\"data\": {\n";
                   int id = rs.getInt("id");
                   bd+="\"id: \""+ id+"\",\n";
                   String  data = rs.getString("somedata");
                   bd+="\"somedata: \""+ data +"\"\n";
                   bd+="},\n";

               }

               bd=bd.substring(0, bd.length()-2) +"\n";
               bd+="}}";
               rs.close();
               stmt.close();
               c.close();
           } catch (Exception e) {
               System.err.println( e.getClass().getName()+": "+ e.getMessage() );
               System.exit(0);
           }

           return bd;
        }

        public String whichURI(URI uri, HttpExchange t){
            switch(uri.toString()){
                //case "/profile": return connectDB();
               // case "/datapost": return postData();
                case "/signinpost": return signInPost(t);
                case "/signuppost": return signUpPost(t);
                case "/exit":
                    return exitPost(t);
                case "/dairyInsert":
                    String s = insertDiaryPost(t);
                    return s;
                case "/getDiaryList": return getListFromDB(t);
                case "/updateDairy": return updateDiaryPost(t);
                case "/deleteDiary": return deleteDiaryPost(t);
                case "/insertDataSettings": return insertDataSettings(t);
                case "/updateDataSettings":return updateDataSettings(t);
                case "/reminderInsert":return reminderInsert(t);
                case "/reminderUpdate":return reminderUpdate(t);
                case "/deleteReminder":return reminderDelete(t);
                case "/fooddataInsert":return foodDataInsert(t);
                case "/deleteFoodData": return foodDataDelete(t);
                case "/updateFoodData": return foodDataUpdate(t);
                case "/insertProductUser": return insertProductUsert(t);



                default: return "";
            }
        }

        private String foodDataUpdate(HttpExchange t) {
            foodDataDelete(t);
            foodDataInsert(t);
            return "";
        }

        private String insertProductUsert(HttpExchange t) {
            String email, name,  grams, carbs;
            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("email").getAsString();
            name = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("name").getAsString();
            grams = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("grams").getAsString();
            carbs = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("carbs").getAsString();

            user=new UserDB();
            user.setEmail(email);
            user.setNameProductUser(name);
            user.setGramsProductUser(grams);
            user.setCarbsProductUser(carbs);


            user.insertProductUser();
            return "true";
        }

        private String foodDataDelete(HttpExchange t) {
            String email, diar_id;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.get("email").getAsString();
            diar_id = jsonObject.get("diary_id").getAsString();

            user=new UserDB();
            user.setEmail(email);
            user.setIddiaryproduct(diar_id);

            user.deleteProduct();
            return "true";
        }

        private String foodDataInsert(HttpExchange t) {
            String email,  diary_id;
            ArrayList<String> name_product = new ArrayList<>(),
                    grams_product=new ArrayList<>(),
                    carbs_product=new ArrayList<>();
            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.get("email").getAsString();
            diary_id = jsonObject.get("diary_id").getAsString();

            JsonArray arrayNameProduct = (JsonArray)jsonObject.get("name_product");
            JsonArray arrayGramsProduct = (JsonArray)jsonObject.get("grams_product");
            JsonArray arrayCarbsProduct = (JsonArray)jsonObject.get("carbs_product");

            for (int i=0; i<arrayNameProduct.size(); i++) {
                name_product.add(arrayNameProduct.get(i).getAsString());
                grams_product.add( arrayGramsProduct.get(i).getAsString());
                carbs_product.add(arrayCarbsProduct.get(i).getAsString());

            }

            user=new UserDB();
            user.setEmail(email);
            user.setIddiaryproduct(diary_id);
            user.insertProduct(name_product, grams_product, carbs_product);
            return "true";
        }

        private String reminderDelete(HttpExchange t) {
            String email, reminderid, reminderdate;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("email").getAsString();
            reminderid = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_id").getAsString();

            user=new UserDB();
            user.setEmail(email);
            user.setReminderid(reminderid);

            user.deleteReminder();
            return "true";
        }

        private String reminderUpdate(HttpExchange t) {
            String email, reminderid, reminderdate, remindertext, repearday, repeatweek, norepeat;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("email").getAsString();
            reminderid = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_id").getAsString();
            reminderdate = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_date").getAsString();
            remindertext = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_text").getAsString();
            repearday = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("repeat_day").getAsString();
            repeatweek = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("repeat_week").getAsString();
            norepeat = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("no_repeat").getAsString();


            user=new UserDB();
            user.setEmail(email);
            user.setReminderid(reminderid);
            user.setReminderdate(reminderdate);
            user.setRemindertext(remindertext);
            user.setRepearday(repearday);
            user.setRepeatweek(repeatweek);
            user.setNorepeat(norepeat);

            user.updateReminder();
            return "true";
        }

        private String reminderInsert(HttpExchange t) {
            String email, reminderid, reminderdate, remindertext, repearday, repeatweek, norepeat;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("email").getAsString();
            reminderid = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_id").getAsString();
            reminderdate = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_date").getAsString();
            remindertext = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("reminder_text").getAsString();
            repearday = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("repeat_day").getAsString();
            repeatweek = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("repeat_week").getAsString();
            norepeat = jsonObject.getAsJsonObject("diary").getAsJsonObject("reminderData").get("no_repeat").getAsString();


            user=new UserDB();
            user.setEmail(email);
            user.setReminderid(reminderid);
            user.setReminderdate(reminderdate);
            user.setRemindertext(remindertext);
            user.setRepearday(repearday);
            user.setRepeatweek(repeatweek);
            user.setNorepeat(norepeat);

            user.insertReminder();
            return "true";
        }

        private String updateDataSettings(HttpExchange t) {
            String email, xemin, xemax, xetarget, xeuser;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("email").getAsString();
            xemin = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_min").getAsString();
            xemax = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_max").getAsString();
            xetarget = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_target").getAsString();
            xeuser = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_user").getAsString();


            user=new UserDB();
            user.setEmail(email);
            user.setXemin(xemin);
            user.setXemax(xemax);
            user.setXetarget(xetarget);
            user.setXeuser(xeuser);

            user.updateSettings();
            return "true";
        }

        //записываем данные в таблицу settings_data
        private String insertDataSettings(HttpExchange t) {
            String email, xemin, xemax, xetarget, xeuser;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("email").getAsString();
            xemin = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_min").getAsString();
            xemax = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_max").getAsString();
            xetarget = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_target").getAsString();
            xeuser = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("xe_user").getAsString();


            user=new UserDB();
            user.setEmail(email);
            user.setXemin(xemin);
            user.setXemax(xemax);
            user.setXetarget(xetarget);
            user.setXeuser(xeuser);

            user.insertSettings();
            return "true";
        }

        private String deleteDiaryPost(HttpExchange t) {
            String email, date;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("email").getAsString();
            date = jsonObject.getAsJsonObject("diary").getAsJsonObject("getData").get("date").getAsString();

            user=new UserDB();
            user.setEmail(email);
            user.setDate(date);


            user.deleteData();
            return "true";
        }


        //Проверяем есть ли в бд почта и пароль пользователя
        UserDB user;

        public String signInPost(HttpExchange t){

            String email;
            String pass;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("SignIn").get("email").getAsString();
            pass = jsonObject.getAsJsonObject("diary").getAsJsonObject("SignIn").get("password").getAsString();

            user=new UserDB();
            user.setEmail(email);
            user.setPass(pass);
            return user.isUserExistDB();

        }

        public String signUpPost(HttpExchange t){
            String email;
            String pass;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("SignUp").get("email").getAsString();
            pass = jsonObject.getAsJsonObject("diary").getAsJsonObject("SignUp").get("password").getAsString();

            user=new UserDB();
            user.setEmail(email); //устанавливаем почту, которую прислал user
            user.setPass(pass); //устанавливаем пароль, которую прислал user
            return user.signUpUser();
        }

        public String exitPost(HttpExchange t){
            String token;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            token = jsonObject.getAsJsonObject("diary").getAsJsonObject("exit").get("token").getAsString();

            user=new UserDB();
            user.setToken(token); //устанавливаем токен юзера

             user.tokenDBDelete();
              return "true";
        }



        public String insertDiaryPost(HttpExchange t){
            String email, blood_sugar, breadunits, insulin, weight, comment, date, iddiary;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("email").getAsString();
            blood_sugar = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("blood_sugar").getAsString();
            breadunits = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("breadunits").getAsString();
            insulin = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("insulin").getAsString();
            weight = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("weight").getAsString();
            comment = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("comment").getAsString();
            date = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("date").getAsString();
            iddiary = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("iddate").getAsString();
            user=new UserDB();
           user.setEmail(email);
            user.setBlood_sugar(blood_sugar);
            user.setBreadunits(breadunits);
            user.setInsulin(insulin);
            user.setWeight(weight);
            user.setComment(comment);
            user.setDate(date);
            user.setIddiary(iddiary);


            user.insertData();
            return "true";
        }


        public String updateDiaryPost(HttpExchange t){
            String email, blood_sugar, breadunits, insulin, weight, comment, date;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("email").getAsString();
            blood_sugar = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("blood_sugar").getAsString();
            breadunits = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("breadunits").getAsString();
            insulin = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("insulin").getAsString();
            weight = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("weight").getAsString();
            comment = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("comment").getAsString();
            date = jsonObject.getAsJsonObject("dairy").getAsJsonObject("insertData").get("date").getAsString();

            user=new UserDB();
            user.setEmail(email);
            user.setBlood_sugar(blood_sugar);
            user.setBreadunits(breadunits);
            user.setInsulin(insulin);
            user.setWeight(weight);
            user.setComment(comment);
            user.setDate(date);


            user.updateData();
            return "true";
        }


        //TODO доедалть
        public String getListFromDB(HttpExchange t){

            String email;
            String pass;

            InputStream s= t.getRequestBody();
            String bodyJson = convertStreamToString(s);
            System.out.print(bodyJson);
            JsonObject jsonObject = new JsonParser().parse(bodyJson).getAsJsonObject();
            email = jsonObject.getAsJsonObject("diary").getAsJsonObject("getlistdiary").get("email").getAsString();


            user=new UserDB();
            user.setEmail(email);
            String ss=user.getListDB();
            return ss;

        }




        public  String postData(){
            return "";
        }



        static String convertStreamToString(java.io.InputStream is) {
            java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }

        public void handle(HttpExchange t) throws IOException {
            URI url=t.getRequestURI();
          //  InputStream s= t.getRequestBody(); //?????
           // String bodyJson = convertStreamToString(s);
            String response = whichURI(url, t);
            byte[] bytes = response.toString().getBytes();
            t.getResponseHeaders().set("Content-Type", "application/json; charset=" + "UTF-8");
            t.sendResponseHeaders(200, bytes.length);
            System.out.print(" YA RUR");



            OutputStream os = t.getResponseBody();
            os.write(bytes);
            os.close();

           /* URI url=t.getRequestURI();
            //String response= connectDB();
            String response= whichURI(url);
           InputStream s= t.getRequestBody();


            String theString = convertStreamToString(s);


            byte[] bytes = response.toString().getBytes();
            t.getResponseHeaders().set("Content-Type", "application/json; charset=" + "UTF-8");
            t.sendResponseHeaders(200, bytes.length);


            OutputStream os = t.getResponseBody();
            os.write(bytes);
            os.close();*/
        }
    }


   /* public static void main(String[] args) throws Throwable {
        ServerSocket ss = new ServerSocket(8080);
        while (true) {
            Socket s = ss.accept();

            System.err.println("Client accepted");
            new Thread(new SocketProcessor(s)).start();
        }
    }

   private static class SocketProcessor implements Runnable {

        private Socket s;
        private InputStream is;
        private OutputStream os;

        private SocketProcessor(Socket s) throws Throwable {
            this.s = s;

            this.is = s.getInputStream();
            this.os = s.getOutputStream();
        }
        String bd;


        public String connectDB(){
           bd="{\"diary\": {\n";

            Connection c = null;
            Statement stmt = null;
            try {
                Class.forName("org.postgresql.Driver");
                c = DriverManager
                        .getConnection("jdbc:postgresql://localhost:5432/postgres",
                                "postgres", "ed371612");
                c.setAutoCommit(false);
                System.out.println("Opened database successfully");

                stmt = c.createStatement();
                ResultSet rs = stmt.executeQuery( "SELECT * FROM data;" );
                while ( rs.next() ) {
                    bd+="\"data\": {\n";
                    int id = rs.getInt("id");
                    bd+="\"id: \""+ id+"\",\n";
                    String  data = rs.getString("somedata");
                    bd+="\"somedata: \""+ data +"\"\n";
                    bd+="},\n";

                }

               bd=bd.substring(0, bd.length()-2) +"\n";
                bd+="}}";
                rs.close();
                stmt.close();
                c.close();
            } catch (Exception e) {
                System.err.println( e.getClass().getName()+": "+ e.getMessage() );
                System.exit(0);
            }

            return bd;
        }

        public void run() {
            try {
                readInputHeaders();
                writeResponse(connectDB());
            } catch (Throwable t) {

            } finally {
                try {
                    s.close();
                } catch (Throwable t) {

                }
                System.err.println("Client processing finished");
            }
        }

        private void writeResponse(String s) throws Throwable {

            System.out.print(s.length());
            String response = "HTTP/1.1 200 OK\r\n" +
                    "Server: YarServer/2009-09-09\r\n" +
                    "Content-Type: application/json; charset=UTF-8\r\n" +
                    "Content-Length: " + (s.getBytes("UTF-8").length) + "\r\n" +
                    "Connection: close\r\n\r\n";
            String result = response + s;
            os.write(result.getBytes());
            os.flush();
        }

        private void readInputHeaders() throws Throwable {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            while(true) {
                String s = br.readLine();
                if(s == null || s.trim().length() == 0) {
                    break;
                }
            }
        }
    }*/
}
