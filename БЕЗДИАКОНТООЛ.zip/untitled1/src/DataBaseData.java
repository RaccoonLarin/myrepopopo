/**
 * Created by Salima on 02.01.2018.
 */
public class DataBaseData {
   private static String link = "jdbc:postgresql://localhost:5432/postgres";
   //private static String link = "jdbc:postgresql://146.185.150.170:5432/postgres";
    private  static  String name = "postgres";
    private  static  String pass = "ed371612";

    public static String getLink() {
        return link;
    }

    public static void setLink(String link) {
        DataBaseData.link = link;
    }

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        DataBaseData.name = name;
    }

    public static String getPass() {
        return pass;
    }

    public static void setPass(String pass) {
        DataBaseData.pass = pass;
    }
}
